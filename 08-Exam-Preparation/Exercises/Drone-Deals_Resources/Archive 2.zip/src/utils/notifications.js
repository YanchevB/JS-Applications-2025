const wrapper = document.getElementById('notifications');
const container = document.getElementById('errorBox');
const span = document.querySelector('span');


export function showNotification(errMsg) {
  wrapper.style.display = 'block';
  container.style.display = 'block';
  span.textContent = errMsg;
  setTimeout(() => {
    container.style.display = 'none';
    wrapper.style.display = 'none';
  }, 3000);
}
